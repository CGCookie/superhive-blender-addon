# superhive-blender-addon
An add-on for Blender to create, publish, and update assets for the Superhive market.

This add-on is in active development by Autotroph and True VFX.
