import functools
import os
import random
import sys
import traceback
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator

import bpy
import mathutils
from bpy.types import (Area, Collection, Constraint, Context, Object, Scene,
                       ShaderNodeMapping, World)

argv = sys.argv
argv = argv[argv.index("--") + 1:]
FILEPATHS = argv[0].split(":--separator--:")
ALL_NAMES = argv[1].split(":--separator--:")
ALL_TYPES = argv[2].split(":--separator--:")
SHADING = argv[3]
OBJECTS_PATH = argv[4]
CAMERA_ANGLE = argv[5]
ADD_PLANE = eval(argv[6])
WORLD_STRENGTH = eval(argv[7])
FILEPATH = FILEPATHS.pop(0)
TYPES = ALL_TYPES.pop(0).split(":--separator2--:")
NAMES = ALL_NAMES.pop(0).split(":--separator2--:")
RENDER_DEVICE = argv[8]
WORLD_NAME = argv[9]


print()
print("FILEPATHS:", FILEPATHS)
print("ALL_NAMES:", ALL_NAMES)
print("ALL_TYPES:", ALL_TYPES)
print("SHADING:", SHADING)
print("OBJECTS_PATH:", OBJECTS_PATH)
print("CAMERA_ANGLE:", CAMERA_ANGLE)
print("ADD_PLANE:", ADD_PLANE)
print("WORLD_STRENGTH:", WORLD_STRENGTH)
print("FILEPATH:", FILEPATH)
print("TYPES:", TYPES)
print("NAMES:", NAMES)
print("RENDER_DEVICE:", RENDER_DEVICE)
print("WORLD_NAME:", WORLD_NAME)
print()


context = bpy.context
scene = context.scene
bpy.ops.wm.open_mainfile(filepath=FILEPATH, load_ui =False)


def enable_gpus(device_type, use_cpus=False):
    preferences = bpy.context.preferences
    cycles_preferences = preferences.addons["cycles"].preferences
    devices=cycles_preferences.get_devices_for_type(device_type)
    

    activated_gpus = []

    for device in devices:
        if device.type == "CPU":
            device.use = use_cpus
        else:
            device.use = True
            activated_gpus.append(device.name)

    cycles_preferences.compute_device_type = device_type

    return activated_gpus


try:
    enable_gpus(RENDER_DEVICE)
except Exception as e:
    print(e)


random_id_source = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"


def get_id(length=6):
    return "".join(random.sample(random_id_source, length))


supports_thumbnails=['MESH','LIGHT']


def does_support_thumbnails(ob: Object):
    return isinstance(ob,bpy.types.Material) or isinstance(ob,bpy.types.World) or  (isinstance(ob,bpy.types.Object) and ob.type in supports_thumbnails and not (isinstance(ob,bpy.types.Object) and ob.type=='MESH' and len(ob.evaluated_get(bpy.context.evaluated_depsgraph_get()).data.polygons)<1)) or (isinstance(ob,bpy.types.NodeTree) and [a for a in ob.interface.items_tree if a.in_out=='OUTPUT']) or SHADING!='Solid'


def delete_object_with_data(obj: Object):
    if obj and obj.name in bpy.data.objects:
        data = obj.data
        isMesh = obj.type == 'MESH'
        bpy.data.objects.remove(obj, do_unlink=True)
        if isMesh:
            bpy.data.meshes.remove(data)


def get_bounding_box_of_collection(col: Collection, objects_to_ignore: set[Object] = None) -> tuple[mathutils.Vector, mathutils.Vector]:
    corners = []
    if objects_to_ignore is None:
        objects_to_ignore = set()
    for ob in col.all_objects:
        if ob in objects_to_ignore:
            continue
        corners.extend([
            (ob.matrix_world @ mathutils.Vector(b))
            for b in ob.bound_box
        ])
    
    min_z = min(((mathutils.Vector(b)).z for b in corners))
    max_z = max(((mathutils.Vector(b)).z for b in corners))
    min_x = min(((mathutils.Vector(b)).x for b in corners))
    max_x = max(((mathutils.Vector(b)).x for b in corners))
    min_y = min(((mathutils.Vector(b)).y for b in corners))
    max_y = max(((mathutils.Vector(b)).y for b in corners))
    
    return mathutils.Vector((min_x, min_y, min_z)), mathutils.Vector((max_x, max_y, max_z))


def get_collections_from_scene(scene: Scene) -> list[Collection]:
    return [
        c
        for c in bpy.data.collections
        if scene.user_of_id(c)
    ]


@contextmanager
def store_and_restore_scene_parameters(add_plane: bool, scene: Scene = None) -> Generator[Any | World, Any, None]:
    if not scene:
        scene = bpy.context.scene
    file_format = scene.render.image_settings.file_format
    filepath = scene.render.filepath
    cameraBackUp = scene.camera
    transparent_backup = scene.render.film_transparent
    rendexXbackUp = scene.render.resolution_x
    rendexYbackUp = scene.render.resolution_y
    backup_world = context.scene.world
    
    scene.render.film_transparent = True
    scene.render.resolution_x = 256
    scene.render.resolution_y = 256
    scene.use_nodes = False
    scene.render.image_settings.file_format = 'PNG'
    
    # WORLD #
    world: World
    world = bpy.data.worlds.get(WORLD_NAME)
    if not world:
        print(f"Appending World: {WORLD_NAME}")
        asset_file = os.path.join(
            os.path.dirname(
                os.path.abspath(__file__)
            ),
            "Assets",
            "Assets.blend" if bpy.app.version>=(3,4,0) else "Assets_Old.blend",
        )
        print(f"    - World Blend: {asset_file}")
        with bpy.data.libraries.load(asset_file, link=False) as (data_from, data_to):
            if WORLD_NAME in data_from.worlds:
                data_to.worlds = [WORLD_NAME]
            else:
                print("    - World not found in data")
        
        world = bpy.data.worlds.get(WORLD_NAME)
        if world:
            print("    - World found!!")
        else:
            print("    - World not found")
    
    world.node_tree.nodes.get("Background").inputs[1].default_value = WORLD_STRENGTH
    
    scene.world = world
    
    # RENDER AREA FOR MATERIAL #
    view_area = next((
        area
        # for window in context.window_manager.windows
        for area in context.window_manager.windows[0].screen.areas
        # for area in window.screen.areas
        if area.type == 'VIEW_3D'
    ), None)
    
    orig_area_type = None
    orig_area_perspective = None
    
    if not view_area:
        orig_area_type = context.area.type
        orig_area_perspective = context.region_data.view_perspective
        
        context.area.type = 'VIEW_3D'
        context.area.spaces.active.region_3d.view_perspective = 'CAMERA'
        view_area = context.area
    
    # CAMERA OBJECT #
    camera_data = bpy.data.cameras.new(name='Camera')
    camera_data.clip_end = 10_000_000
    camera_data.clip_start = 0
    camera_data.lens = 80
    
    camera_object = bpy.data.objects.new('Camera', camera_data)
    scene.collection.objects.link(camera_object)
    
    # TRACK OBJECT #
    track_object = bpy.data.objects.new("Track", object_data=None)
    scene.collection.objects.link(track_object)
    
    # ADD PLANE #
    ground_plane = None
    if add_plane:
        ground_plane = add_ground_plane(scene)
    
    yield view_area, camera_object, track_object, ground_plane
    
    # bpy.data.objects.remove(track_object)
        
    if orig_area_type:
        context.area.type = orig_area_type
        context.region_data.view_perspective = orig_area_perspective
    
    scene.render.image_settings.file_format = file_format
    scene.render.filepath = filepath
    scene.camera = cameraBackUp
    scene.render.film_transparent = transparent_backup
    scene.render.resolution_x = rendexXbackUp
    scene.render.resolution_y = rendexYbackUp
    scene.world = backup_world
    
    if backup_world != world:
        if world.node_tree.nodes.get("Environment Texture").image:
            bpy.data.images.remove(world.node_tree.nodes.get("Environment Texture").image)
        bpy.data.worlds.remove(world)
    
    if camera_object:
        bpy.data.objects.remove(camera_object, do_unlink=True)
        
    if ground_plane:
        delete_object_with_data(ground_plane)


def setup_camera_and_track(dist: mathutils.Vector, camera_object: Object, track_object: Object) -> Constraint:
    camera_object.location = mathutils.Vector((
        -dist if '-X' in CAMERA_ANGLE else (dist if 'X' in CAMERA_ANGLE else 0),
        dist if '-Y' in CAMERA_ANGLE else (-dist if 'Y' in CAMERA_ANGLE else 0),
        -dist if '-Z' in CAMERA_ANGLE else dist
    ))
    
    constraint = camera_object.constraints.new('TRACK_TO')
    constraint.name = "SH_Track_To"
    constraint.target = track_object
    constraint.up_axis = 'UP_Y'
    
    # with context.temp_override(object=camera_object):
    #         bpy.ops.constraint.apply(constraint=constraint.name)
    
    return constraint


def add_ground_plane(scene: Scene) -> Object:
    mesh_data = bpy.data.meshes.new("SH_Plane")
    polycoords = [
        (1000, 1000, 0), (1000, -1000, 0),
        (-1000, -1000, 0), (-1000, 1000, 0)
    ]
    polyIndices = [
        (i, (i + 1) % (len(polycoords)))
        for i in range(0, len(polycoords))
    ]
    mesh_data.from_pydata(
        polycoords,
        polyIndices,
        [[i for i in range(0, len(polycoords))]]
    )
    mesh_data.validate()
    
    ground_plane = bpy.data.objects.new("SH_Plane", mesh_data)
    
    subsurf_mod: bpy.types.SubsurfModifier = ground_plane.modifiers.new(type='SUBSURF', name="TA_SUBSURF")
    subsurf_mod.levels = 4
    subsurf_mod.render_levels = 4
    subsurf_mod.subdivision_type = 'SIMPLE'
    
    scene.collection.objects.link(ground_plane)
    
    return ground_plane


def setup_scene_for_render(scene: Scene, camera_object: Object, path: Path, path_id_name:str):
    render_path = path / (bpy.path.clean_name(path_id_name+"_"+get_id(8))+'.png')
    
    scene.render.filepath = str(render_path)
    scene.camera = camera_object
    
    return render_path


def render_image(context: Context, view_area: Area, shading: str, scene: Scene, material_render_func: callable):
    engine = scene.render.engine
    if shading == 'Material':
        view_area.spaces[0].shading.type = 'MATERIAL'
        view_area.spaces[0].overlay.show_overlays = False
        material_render_func()
    elif shading == 'Eevee':
        scene.render.engine = 'BLENDER_EEVEE_NEXT' if bpy.app.version >= (4, 2) else 'BLENDER_EEVEE'
        bpy.ops.render.render(write_still=True)
    else: # Cycles
        samples = context.scene.cycles.samples
        context.scene.cycles.samples = 64
        scene.render.engine = 'CYCLES'
        bpy.ops.render.render(write_still=True)
        context.scene.cycles.samples = samples
    scene.render.engine = engine


def capture_thumbnail_for_collection(context: bpy.types.Context, col: bpy.types.Collection, path: Path, shading="Material", angle='X', add_plane=True):
    with store_and_restore_scene_parameters(add_plane, context.scene) as (view_area, camera_object, track_object, ground_plane):
        view_area: Area
        camera_object: Object
        track_object: Object
        ground_plane: Object
        scene: Scene = context.scene
        
        if col not in get_collections_from_scene(scene):
            scene.collection.children.link(col)
        
        bottom_left, top_right = get_bounding_box_of_collection(col, objects_to_ignore=set((ground_plane,)))
        local_bbox_center = (bottom_left + top_right) / 2
        
        if add_plane and ground_plane:
            min_z = bottom_left.z
            ground_plane.location = (local_bbox_center.x, local_bbox_center.y, min_z)
        
        global_bbox_center = local_bbox_center
        track_object.location = global_bbox_center
        dist = max([
            abs(top_right.x - bottom_left.x),
            abs(top_right.y - bottom_left.y),
            abs(top_right.z - bottom_left.z)
        ])*2
        constraint = setup_camera_and_track(dist, camera_object, track_object)
                
        # Must come after extra camera location stuff
        with context.temp_override(object=camera_object):
            bpy.ops.constraint.apply(constraint=constraint.name)
        
        bpy.data.objects.remove(track_object)
        
        render_path = setup_scene_for_render(scene, camera_object, path, col.name)
        
        override = context.copy()
        view_area.spaces.active.region_3d.view_perspective = 'CAMERA'
        override['area'] = view_area
        override['space_data'] = view_area.spaces.active
        override['screen'] = context.window_manager.windows[0].screen
        override['window'] = context.window_manager.windows[0]
        override['active'] = col.all_objects[0] if col.all_objects else None
        if col.all_objects:
            override['selected_objects'] = [col.all_objects[0],]

        map_node: ShaderNodeMapping = scene.world.node_tree.nodes.get("Mapping")
        if map_node:
            rot_inp = map_node.inputs[2]
            rot_inp.default_value = [
                rot_inp.default_value[0],
                rot_inp.default_value[1],
                0.785398-camera_object.rotation_euler.z
            ]
        
        hidden_render: list[Object] = []
        hidden_viewport: list[Object] = []
        unselected: list[Object] = [
            a
            for a in scene.objects
            if a.name not in col.all_objects
        ]
        
        for obj in unselected:
            if obj.hide_render == False:
                obj.hide_render = True
                hidden_render.append(obj)
            if obj.hide_viewport == False:
                obj.hide_viewport = True
                hidden_viewport.append(obj)
        
        def render_material():
            with context.temp_override(**override):
                bpy.ops.render.opengl(write_still=True)
        
        render_image(context, view_area, shading, scene, render_material)
        
        for obj in hidden_render:
            obj.hide_render = False
        for obj in hidden_viewport:
                obj.hide_viewport = False
    
    return render_path


def capture_thumbnail(context: bpy.types.Context, object: bpy.types.Object, path: Path, shading="Material", add_plane=True) -> Path:
    with store_and_restore_scene_parameters(add_plane, context.scene) as (view_area, camera_object, track_object, ground_plane):
        view_area: Area
        camera_object: Object
        track_object: Object
        ground_plane: Object
        scene: Scene = context.scene
        
        if object not in scene.objects[:]:
            scene.collection.objects.link(object)
        
        local_bbox_center = 0.125 * sum(
            (
                mathutils.Vector(b)
                for b in object.bound_box
            ),
            mathutils.Vector()
        )
        
        if add_plane and ground_plane:
            min_z = min((
                (object.matrix_world @ mathutils.Vector(b)).z
                for b in object.bound_box
            ))
            ground_plane.location = (object.location.x, object.location.y, min_z)
        
        global_bbox_center = object.matrix_world @ local_bbox_center
        track_object.location = global_bbox_center
        dist = max(object.dimensions[:])*2
        constraint = setup_camera_and_track(dist, camera_object, track_object)
        object_matrix = mathutils.Matrix.LocRotScale(
            track_object.location, object.rotation_quaternion, (1,1,1)
        )
        camera_object.location = object_matrix @ camera_object.location
        
        # Must come after extra camera location stuff
        with context.temp_override(object=camera_object):
            bpy.ops.constraint.apply(constraint=constraint.name)
        
        bpy.data.objects.remove(track_object)
        
        render_path = setup_scene_for_render(scene, camera_object, path, object.name)

        view_area.spaces.active.region_3d.view_perspective = 'CAMERA'

        map_node: ShaderNodeMapping = scene.world.node_tree.nodes.get("Mapping")
        if map_node:
            rot_inp = map_node.inputs[2]
            rot_inp.default_value = [
                rot_inp.default_value[0],
                rot_inp.default_value[1],
                0.785398-camera_object.rotation_euler.z
            ]
        
        hidden_render: list[Object] = []
        hidden_viewport: list[Object] = []
        unselected: list[Object] = [
                a
                for a in scene.objects
                if a !=object and a!=ground_plane
            ]
        
        for obj in unselected:
            if obj.type != "LIGHT" and obj.hide_render == False:
                obj.hide_render = True
                hidden_render.append(obj)
            if obj.hide_get() == False:
                obj.hide_set(True)
                hidden_viewport.append(obj)
        
        def render_material():
            og_hide_render = object.hide_render
            object.hide_render = False
            bpy.ops.render.render(write_still=True)
            object.hide_render = og_hide_render
        
        render_image(context, view_area, shading, scene, render_material)
        
        for obj in hidden_viewport:
            obj.hide_set(False)
        for obj in hidden_render:
            obj.hide_render = False
    
    return render_path


def create_thumbnail(context, ob, shading='Solid'):
    thumbnail_path = Path(OBJECTS_PATH, "Thumbanils")
    thumbnail_path.mkdir(parents=True, exist_ok=True)
    
    if shading != 'Solid':
        if isinstance(ob,bpy.types.Collection):
            path=capture_thumbnail_for_collection(
                context,
                ob,
                thumbnail_path,
                shading,
                add_plane=ADD_PLANE
            )
        else:
            path = capture_thumbnail(
                context,
                ob,
                thumbnail_path,
                shading,
                add_plane=ADD_PLANE
            )
        #print(path)
        if os.path.isfile(path):
            with context.temp_override(id=ob):
                bpy.ops.ed.lib_id_load_custom_preview(filepath=str(path))
    else:
        ob.asset_generate_preview()


def check_if_volumetric(mat):
    if mat.use_nodes:
        output_nodes=[node for node in mat.node_tree.nodes if node.bl_idname=='ShaderNodeOutputMaterial']
        for node in output_nodes:
            if node.inputs[1].is_linked:
                return True


def create_preview(objects: list[bpy.types.ID]):
    global FILEPATHS, FILEPATH, ALL_NAMES, ALL_TYPES, NAMES, TYPES
    obs=objects[:]
    while obs:
        ob=obs[0]
        if not ob.preview or any(ob.preview.image_pixels[:]) or SHADING != "Solid" or (type=='MATS' and check_if_volumetric(ob)):
            obs.pop(0)
        else:
            return 1
        
    bpy.ops.wm.save_mainfile()
    
    bk = FILEPATH + "1"
    if os.path.exists(bk):
        os.remove(bk)
    
    if FILEPATHS and ALL_NAMES and ALL_TYPES:
        FILEPATH = FILEPATHS.pop(0)
        NAMES = ALL_NAMES.pop(0).split(":--separator--:")
        TYPES = ALL_TYPES.pop(0).split(":--separator--:")
        bpy.ops.wm.open_mainfile(filepath=FILEPATH, load_ui=False)
        start_regenerating()
    else:
        bpy.ops.wm.quit_blender()
    return None


def start_regenerating():
    print("Types:", TYPES)
    print("Names:", NAMES)
    try:
        objects=[]
        for i,a in enumerate(TYPES):
            if a == 'COLLECTION':
                ob = bpy.data.collections.get(NAMES[i])
                if ob:
                    objects.append(ob)
                    create_thumbnail(bpy.context,ob,SHADING)
            elif a == 'MATERIAL':
                ob = bpy.data.materials.get(NAMES[i])
                objects.append(ob)
                if ob:
                    ob.asset_generate_preview()
            else:
                ob = bpy.data.objects.get(NAMES[i])
                if ob:
                    if ob.type in {'MESH','CURVE','SURFACE','TEXT','META'}:
                        ob.display_type = 'TEXTURED'
                    if does_support_thumbnails(ob):
                        objects.append(ob)
                        create_thumbnail(bpy.context,ob,SHADING)
        bpy.app.timers.register(
            functools.partial(
                create_preview,
                objects
            ),
            first_interval=0
        )
    except Exception as e:
        traceback.print_exc()
        print(e,"An Error Ocurred!")


if __name__ == "__main__":
    start_regenerating()
